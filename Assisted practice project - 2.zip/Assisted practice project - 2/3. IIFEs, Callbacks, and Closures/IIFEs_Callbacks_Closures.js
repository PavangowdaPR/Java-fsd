//IIFE and Closure
const empId = (function() {
    let count = 0;
    return function() {
      ++count;
      return `emp${count}`;
    };
  })();
  
  console.log("New Emplyee IDs are listed here");
  console.log("Likitha: "+empId()); 
  console.log("Vandana: "+empId()); 
  console.log("Priya: "+empId());
   

  //Callbacks
  console.log("\n"); //to start the output from the neext line
  function fullName(firstName, lastName, callback){
    console.log("My name is " + firstName + " " + lastName);
    callback(firstName);
  }
  
  var greeting = function(ln){
    console.log('Welcome ' + ln);
  };
  
  fullName("Likitha", "DB", greeting);
  console.log("\n");
  fullName("Vandana", "N", greeting);
  console.log("\n");
  fullName("Priya", "UD", greeting);
